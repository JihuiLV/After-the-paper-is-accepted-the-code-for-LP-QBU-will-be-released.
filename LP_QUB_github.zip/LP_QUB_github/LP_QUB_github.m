function doa = LP_QUB_github(signal_rec,M,true_doa,JIAODU,JIANGE)
RealDOA = true_doa;
NNN_MAX = 30;
aaaaaa = 0;
Y = signal_rec;
K = size(Y,2);
R=Y*Y'/K;
%% 
jiange = JIANGE;
N=length(JIAODU);     
A=exp(-1i*pi*(0:M-1)'*sin(JIAODU*pi/180));  
%% 
tol = 1e-2;    
aaa0 = 1e-4;
a_i_0=aaa0*ones(N,1);   %
b_i_0=a_i_0;

a_i=a_i_0;
b_i=b_i_0;

a_sigma_0 = aaa0;  
b_sigma_0 = a_sigma_0;  

WS = pinv(A)*Y;

E_sigma0=1/10^(-1)*(M*K)/(norm(Y,'fro'))^2; 
E_beta =1./sqrt(sum(abs(A'*Y),2)/(M*K)); 
a_min =1e-2;    
%%
for i_x =1:1:length(JIAODU)
  X_NORM(i_x,1) =max(norm(WS(i_x,:),2),a_min);
end
%% 
DUIJ     = diag(X_NORM./E_beta) ;  
SIGMA    = inv(1/E_sigma0*eye(M)+A*DUIJ*A') ;
SIGMA_NI = DUIJ-DUIJ*A'*SIGMA*A*DUIJ;
E_WS     = 1.0*SIGMA_NI*E_sigma0*A'*Y;
%% E_WS
convergence = 1;
NNN = 0;
E_WS_OLD = E_WS; %


while convergence
%% 1
       % for i_x =1:1:length(JIAODU)
       % X_NORM(i_x,1) = max((norm(E_WS(i_x,:),2)), a_min);
       % end
%% 2
       for i_x =1:1:length(JIAODU)
       R_QMB = A*diag(X_NORM./E_beta)*A'-A(:,i_x)*X_NORM(i_x,1)./E_beta(i_x,1)*A(:,i_x)' + 1/E_sigma0*eye(M);
       R_NI = inv(R_QMB);
       stheta2 =real(A(:,i_x)'*R_NI*A(:,i_x)) ;
       qtheta2 = real(A(:,i_x)'*R_NI*R*R_NI*A(:,i_x));
       X_NORM(i_x,1) = max(real((sqrt(K*qtheta2)-E_beta(i_x,1))/stheta2),a_min);
       end
%% 
       a_sigma = a_sigma_0+M*K;
       b_sigma = b_sigma_0+norm(Y-A*E_WS,'fro')^2+K*abs((trace(A'*A*SIGMA_NI)));
       E_sigma0 = a_sigma/b_sigma;

%% 
     
       DUIJ = diag(X_NORM./E_beta) ;  
       SIGMA   =  inv(1/E_sigma0*eye(M)+A*DUIJ*A') ;
       SIGMA_NI = DUIJ-DUIJ*A'*SIGMA*A*DUIJ;

       E_WS     =  1.0*SIGMA_NI*E_sigma0*A'*Y;
       
       for i_a=1:1:length(JIAODU)
       a_i(i_a,1) = abs(a_i_0(i_a,1)) +2*K;
       b_i(i_a,1) = abs(b_i_0(i_a,1)) + X_NORM(i_a,1) + (norm(E_WS(i_a,:),'fro')^2+ K*real(abs(SIGMA_NI(i_a,i_a))))/X_NORM(i_a,1);
       E_beta(i_a,1) = ((abs(a_i(i_a,1)/b_i(i_a,1))));
       end
   
      E_WS_NEW = E_WS;
      ERROR_E_WS = norm(E_WS_NEW-E_WS_OLD,'fro');
      E_WS_OLD = E_WS_NEW;
      if ERROR_E_WS<=tol
          break;
      end

      if NNN>NNN_MAX
          break;
      end
      NNN= NNN+1;
end
%% 
for i_n = 1:1:N
    power(i_n,1) = X_NORM(i_n,1)/E_beta(i_n,1); 
end
[~, S_ID] = findpeaks((power),'sortstr','descend'); %% 
%% 
SHUMU = S_ID(1:length(RealDOA),1); 

SIGMA_0=1/E_sigma0; 

RS_JD = JIAODU(1,SHUMU);
AP = A(:,SHUMU);

IT_MAX = 10;   %% 
DOA_R = RS_JD ;

for iii=1:1:IT_MAX
    XH_GL= X_NORM(SHUMU)./E_beta(SHUMU);

    for i_sm=1:1:length(SHUMU)
     R_POWER = SIGMA_0*eye(M)+AP*diag(XH_GL)*AP'-AP(:,i_sm)*XH_GL(i_sm,1)*AP(:,i_sm)';
     R_POWER_NI = inv(R_POWER);
     BLFW = RS_JD(1,i_sm)-jiange:0.1:RS_JD(1,i_sm)+jiange;

     for i_bl = 1:1:length(BLFW)
         AL = exp(-1i*pi*(0:M-1)'*sin(BLFW(1,i_bl)*pi/180));
         ztheta = AL'*R_POWER_NI*AL;
         qtheta = K*AL'*R_POWER_NI*R*R_POWER_NI*AL;
         FWZ(1,i_bl) = -K*log(1+XH_GL(i_sm)*ztheta) +  qtheta/( XH_GL(i_sm)^(-1) + ztheta) +E_beta(SHUMU(i_sm))*X_NORM(SHUMU(i_sm));
     end
     
     [~,index]=max(FWZ);
     RS_JD(1,i_sm)=BLFW(1,index);
    end

    AP = exp(-1i*pi*(0:M-1)'*sin(RS_JD*pi/180));
    A(:,SHUMU) = AP;


%% 
DOA_R2 = RS_JD ;
if norm(DOA_R2-DOA_R)<=1e-2
    aaaaaa = aaaaaa +1;
    break;
end
DOA_R = DOA_R2;

%% 
       for i_x =1:1:length(JIAODU)
       R_QMB = A*diag(X_NORM./E_beta)*A'-A(:,i_x)*X_NORM(i_x,1)./E_beta(i_x,1)*A(:,i_x)' +  SIGMA_0*eye(M);
       R_NI = inv(R_QMB);
       stheta2 =real(A(:,i_x)'*R_NI*A(:,i_x)) ;
       qtheta2 = real(A(:,i_x)'*R_NI*R*R_NI*A(:,i_x));
       X_NORM(i_x,1) = max(real((sqrt(K*qtheta2)-E_beta(i_x,1))/stheta2),a_min);
       end
%% 
       a_sigma = a_sigma_0+M*K;
       b_sigma = b_sigma_0+norm(Y-A*E_WS,'fro')^2+K*abs((trace(A'*A*SIGMA_NI)));
       E_sigma0 = a_sigma/b_sigma;
       SIGMA_0 = 1/E_sigma0;
%%
       for i_a=1:1:length(JIAODU)
       a_i(i_a,1) = abs(a_i_0(i_a,1)) + 2*K;
       b_i(i_a,1) = abs(b_i_0(i_a,1)) + X_NORM(i_a,1) + (norm(E_WS(i_a,:),'fro')^2+ K*real(abs(SIGMA_NI(i_a,i_a))))/X_NORM(i_a,1);
       E_beta(i_a,1) = ((abs(a_i(i_a,1)/b_i(i_a,1))));
       end
%% 
       DUIJ = diag(X_NORM./E_beta) ;  
       SIGMA   =  inv(1/E_sigma0*eye(M)+A*DUIJ*A') ;
       SIGMA_NI = DUIJ-DUIJ*A'*SIGMA*A*DUIJ;
       E_WS     =  1.0*SIGMA_NI*E_sigma0*A'*Y;
end
doa = sort(RS_JD);
end