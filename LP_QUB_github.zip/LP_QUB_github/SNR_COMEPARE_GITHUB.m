clc
clear all;
close all;
%%
M = 10;
K = 20; 
snr= -8:2:18;
mt=200;


ERROR_LP_QUB = zeros(mt,length(snr));


for i_snr = 1:1:length(snr)
    SNR = snr(i_snr);
for j_mt = 1:1:mt
    %% 定义相应的参数
    jiange = 3;  
    true_doa =[-11.5, 2.5, 11.5];
    signal_number = length(true_doa);
    JIAODU = -90:jiange :90;  %%过完备基
    A = exp(-1i*pi*(0:M-1)'*sin(JIAODU/180*pi));
    %% 测角
    [signal_rec,signal_rec2]=signal_sparse(M, true_doa, SNR, K);
    DOA_LP_QUB = LP_QUB_github(signal_rec,M,true_doa,JIAODU,jiange);
    %% ERROR的计算
    ERROR_LP_QUB(j_mt,i_snr) = sum((DOA_LP_QUB-true_doa).^2);
end
end
WUCHA_LP_QUB =sqrt(sum(ERROR_LP_QUB)/mt/signal_number);

figure(1)
semilogy(snr,WUCHA_LP_QUB,'r->','linewidth',1.5); hold on


